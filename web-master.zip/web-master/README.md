# web
building a web with html, css, js, php, notepad, dreamweaver, and many browsers

currently figuring out the the syle sheets....

and how to build it for mobile web browser usage

dreamweaver....not sure why so expensive, I have a notepad good for a while

useful tools:
http://www.colorhexa.com/
