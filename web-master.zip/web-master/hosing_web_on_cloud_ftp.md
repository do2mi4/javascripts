/the purpose of the article is to give directions how to to host a website on a cloud.
/here, we use IBM ftp as an example
/usually, we will buy an FTP and host web content on the site. However, a fixed FTP is not scalable.
/some clouds could be free for a while, e.g. IBM, Azure, etc.
