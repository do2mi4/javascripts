javascriptRevision
==================

Just reviewing some basic javascripts here. 
